README file - dfu-util 0.6 binaries for darwin-ppc

SOURCE CODE:

The sources for the libusb library (here distributed as libusb-1.0.0.dylib)
can be found at http://libusb.org/

The sources for dfu-util and dfu-suffix can be found
at http://dfu-util.gnumonks.org/

See individual source files for full copyright information.
See enclosed COPYING.* files for distribution.

BUILDING:

The binaries were built on MacOSX 10.4.11 (Darwin 8.11.0) using
powerpc-apple-darwin8-gcc-4.0.1.

INSTALLATION:

Copy libusb-1.0.0.dylib to e.g. /usr/local/lib
Copy dfu-util and dfu-suffix to e.g. /usr/local/bin

